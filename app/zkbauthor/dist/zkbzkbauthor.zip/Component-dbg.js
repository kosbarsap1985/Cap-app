sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("zkb.zkbauthor.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);